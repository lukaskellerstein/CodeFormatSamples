# Steps

1. Create app

`ng new TestApp2 --style=scss`

2. Install pretier

`yarn add prettier@latest --dev --exact`

3. Remove code formating rules from tslint.json.

4. Add `.prettierrc` file with some default configuration

```JSON
{
 "printWidth": 120,
 "singleQuote": true,
 "useTabs": false,
 "tabWidth": 2,
 "semi": true,
 "bracketSpacing": true
}
```

5. Add new libraries

`yarn add pre-commit@latest --dev`
`yarn add pretty-quick@latest --dev`

6. Make change and commit into Git

changes like a lot of new lines in app.component.ts file

`git commit -am "test commit"`


# Recommended settings

1. Remove from TsLint code formatting rules which cause conflict with Prettier

2. Set the rules from your .editorconfig to avoid conflict with Prettier

3. Use this settings in .prettierrc

```JSON
{
 "printWidth": 120,
 "tabWidth": 2,
 "useTabs": true,
 "semi": true,
 "singleQuote": true,
 "bracketSpacing": true,
 "parser": "typescript"
}
```