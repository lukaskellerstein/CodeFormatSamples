1. TestApp - basics

a) manually by command `prettier --config ./.prettierrc --write ./src/app/app.component.ts`
b) automatically by VSCODE extension + user setting 

2. TestApp2 - precommit

Make some changes and 
run `git commit -am "test commit"`