# Steps

1. Create app

`ng new TestApp --style=scss`

2. Install pretier

`yarn add prettier --dev --exact`

3. Remove code formating rules from tslint.json.

4. Add `.prettierrc` file with some default configuration

```JSON
{
 "printWidth": 120,
 "singleQuote": true,
 "useTabs": false,
 "tabWidth": 2,
 "semi": true,
 "bracketSpacing": true
}
```

5. Add `.prettierignore` file and add package.json in it.

```JS
*.json
*.md
```

6. Run prettier manually

`prettier --config ./.prettierrc --write ./src/app/app.component.ts`

7. Install VSCode extension

https://marketplace.visualstudio.com/items?itemName=esbenp.prettier-vscode

8. Set VSCODE user settings

`"editor.formatOnSave": true`




# Recommended settings

1. Remove from TsLint code formatting rules which cause conflict with Prettier

2. Set the rules from your .editorconfig to avoid conflict with Prettier

3. Use this settings in .prettierrc

```JSON
{
 "printWidth": 120,
 "tabWidth": 2,
 "useTabs": true,
 "semi": true,
 "singleQuote": true,
 "bracketSpacing": true,
 "parser": "typescript"
}
```