import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'my-button',
  templateUrl: './my-button.component.html',
  styleUrls: ['./my-button.component.scss']
})
export class MyButtonComponent implements OnInit {

  @Input() type: string;
  @Input() color: string;
  @Input() theme: string;
  @Input() var1: string;
  @Input() var2: string;
  @Input() var3: string;
  @Input() var4: string;
  @Input() var5: string;


  constructor() { }

  ngOnInit() {
  }

}
