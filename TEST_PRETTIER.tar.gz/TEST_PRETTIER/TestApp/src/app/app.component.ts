import { Component } from '@angular/core';

@Component({
	selector: 'app-root',
	templateUrl: './app.component.html',
	styleUrls: ['./app.component.scss']
})
export class AppComponent {
	type: string;
	color: string;
	theme: string;
	var1: string;
	var2: string;
	var3: string;
	var4: string;
	var5: string;

	ngOnInit() {
		const variable1 = '';
		let variable2 = '';
		const variable_2 = '';
	}

	//Bad comment
	testFunc1(inputVar1) {
		console.debug(inputVar1);
	}

	testFunc2(inputVar2: string) {
		console.log(inputVar2);
	}
}
