import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  type: string;
	color: string;
	theme: string;
	var1: string;
	var2: string;
	var3: string;
	var4: string;
	var5: string;
}
