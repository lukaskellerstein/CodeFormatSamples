# Steps

1. Create app

`ng new TestApp --style=scss`

2. Install js-beautify

`yarn add js-beautify@latest --dev`

3. Remove code formating rules from tslint.json.

4. Add `.jsbeautifyrc` file with some default configuration

```JSON
{
  "html": {
    "brace_style": "collapse",
    "indent_char": " ",
    "indent_scripts": "normal",
    "indent_size": 2,
    "wrap_indent": 8,
    "wrap_line_length": 80,
    "max_preserve_newlines": 1,
    "preserve_newlines": true,
    "unformatted": ["a", "sub", "sup", "b", "i", "u"]
  }
}
```

6. Create helper file in ./helpers/glob-ls.js

```JS
// A small helper that will list all files using `glob` lib
// Usage: `node bin/glob-ls.js 'src/**/*.js'`
const glob = require('glob');
const patterns = process.argv.slice(2);
patterns.forEach(pattern => {
  glob(pattern, {}, function(err, files) {
    if (err) throw err;
    process.stdout.write(files.join('\n') + '\n');
  });
});
```

6. Run js-beautify manually

`node bin/glob-ls.js 'src/**/*.html' 'build/**/*.html.ejs' | xargs node_modules/.bin/html-beautify -r`


7. Run js-beautify as NPM script

```JSON
"format:html": "node bin/glob-ls.js 'src/**/*.html' 'build/**/*.html.ejs' | xargs node_modules/.bin/html-beautify -r"
```

```Shell
`yarn run format:html`
```