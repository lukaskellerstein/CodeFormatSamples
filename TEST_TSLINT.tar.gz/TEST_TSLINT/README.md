1. TestApp - empty

Run `ng lint`

2. TestApp - rules

Run `ng lint`

3. Autofix

Run `yarn lint:fix`

4. Precommit

Make some changes and 
run `git commit -am "test commit"`
