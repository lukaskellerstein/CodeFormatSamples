import { Component } from '@angular/core';
import { of } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {







  
  ngOnInit(){
    const variable1 = "";
    let variable2 = '';
    const variable_2 = '';
  }

  //Bad comment
  testFunc1(inputVar1){
    console.debug(inputVar1);
  }

  testFunc2(inputVar2: string){
    console.log(inputVar2)
  }

  testFunc3() {
    of(null).subscribe((value)=>{console.log("-----------------------------------------------some very long string --------------------------------------------")});
  }
  
}
