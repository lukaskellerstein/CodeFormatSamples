# Steps

Create app

`ng new TestApp --style=scss`

Run lint

`ng lint`


# Recommended settings


1. In angular.json set right prefix for the App's components

```JSON
"prefix": "ves",
```

2. In src/tsconfig.json set the same prefix

```JSON
{
    "extends": "../tslint.json",
    "rules": {
        "directive-selector": [
            true,
            "attribute",
            "ves",
            "camelCase"
        ],
        "component-selector": [
            true,
            "element",
            "ves",
            "kebab-case"
        ]
    }
}
```